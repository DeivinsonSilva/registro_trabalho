function RegistroTable() {
  return (
    <table border="1" style={{ marginTop: '2rem', width: '100%' }}>
      <thead>
        <tr>
          <th>Trabalhador</th>
          <th>Fazenda</th>
          <th>Serviço</th>
          <th>Produção</th>
          <th>Preço</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        {/* Dados fictícios ou vindos da API */}
      </tbody>
    </table>
  )
}

export default RegistroTable
