function RegistroForm() {
  return (
    <form>
      <label>Trabalhador:</label>
      <input type="text" />

      <label>Fazenda:</label>
      <input type="text" />

      <label>Serviço:</label>
      <input type="text" />

      <label>Produção:</label>
      <input type="number" />

      <label>Preço:</label>
      <input type="number" />

      <button type="submit">Salvar</button>
    </form>
  )
}

export default RegistroForm
