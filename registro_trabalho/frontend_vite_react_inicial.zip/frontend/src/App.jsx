import RegistroPage from './pages/RegistroPage'

function App() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Registro de Trabalho</h1>
      <RegistroPage />
    </div>
  )
}

export default App
