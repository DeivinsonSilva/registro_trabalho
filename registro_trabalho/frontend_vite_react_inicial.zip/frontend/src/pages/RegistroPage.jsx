import RegistroForm from '../components/RegistroForm'
import RegistroTable from '../components/RegistroTable'

function RegistroPage() {
  return (
    <>
      <RegistroForm />
      <RegistroTable />
    </>
  )
}

export default RegistroPage
